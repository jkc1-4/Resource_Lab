# Resource-Lab
## Useful Resources Provider


Are your routines getting a hectic one ? Do you want something that makes you hard work a little lesser and your day more productive ?
You are just at the right place!! This resource lab will definitely help you achieve for what you are looking for!

This lab provides you with all the free resources that makes your daily routine more organized and easier. Just a click and your work is done. Nobody will ever want to be deprived of these most useful apps/webs. To make your work a little more easier , these resources have been divided into different categories , just chose yours and you are good to go. These categories meet almost all  the requirements that not only the student but the industrialists would require to work more efficiently.

#### Saves Time!!
Give a break to your searching. Save your time by visiting this lab and get all your work done.

#### Work Smarter!!
Work smarter and not harder. Get all the apps there that you should use to offer yourself a relaxed routine.

#### Free!!
No more turning to paid sites. Get all your work done absolutely free.
<br>
<br>


### Team : <strong>GROOT</strong>

1. [Nandini Jain](https://github.com/nandiniinj)<br>
2. [Isha Kondurkar](https://github.com/Isha-1290)<br>
3. [Suhani Singhal](https://github.com/suhani3502)<br>
4. [Jahnavi Chauhan](https://github.com/jkc1-4)<br>

## [Click Here](https://nandiniinj.github.io/Resource-Lab/) to view the Project.

### [Click Here](https://drive.google.com/drive/folders/1OpQEhy5wr68w3C-iKECZE3seJbt9bp49?usp=sharing) to view the Expanation Presentation

